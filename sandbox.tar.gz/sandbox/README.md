# Sandbox Scaffold

This repository provides a minimal Flask application scaffold intended for
further development.  It exposes a handful of routes and models but leaves
business logic and advanced features unimplemented.  Human developers can
extend this scaffold to build a fully‑featured RBAC system, G‑Code parser,
and thumbnail renderer.

## Project Structure

```
sandbox/
├─ app/                   # Flask application package
│  ├─ __init__.py         # Application factory and configuration
│  ├─ __main__.py         # Entry point for `python -m app`
│  ├─ models.py           # SQLAlchemy models (User, Item)
│  ├─ routes.py           # HTTP routes and view functions
│  ├─ services.py         # Stubs for parsing and rendering
│  └─ templates/          # Jinja2 templates
│      ├─ base.html
│      ├─ login.html
│      ├─ rbac_demo.html
│      ├─ gcode_upload.html
│      └─ items_list.html
├─ uploads/               # File uploads are stored here (empty by default)
├─ migrations/            # Alembic environment and baseline migration
│  ├─ env.py
│  └─ versions/
│      └─ 0001_initial.py
├─ selfcheck.sh           # Script to verify the scaffold boots and basic routes work
├─ Dockerfile             # Build instructions for containerising the app
├─ docker-compose.yml     # Compose file to run the container with mounted volumes
├─ requirements.txt       # Python dependencies
└─ README.md              # This file
```

Follow the instructions in the challenge description to extend this scaffold.